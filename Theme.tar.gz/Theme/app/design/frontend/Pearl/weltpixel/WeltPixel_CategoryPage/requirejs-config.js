var config = {
    config: {
        mixins: {
            'Magento_Swatches/js/swatch-renderer': {
                'WeltPixel_CategoryPage/js/swatch-renderer': true
            }
        }
    }
};