var config = {
    map: {
        '*': {
            ajaxinfinitescroll: 'WeltPixel_AjaxInfiniteScroll/js/ajaxinfinitescroll'
        }
    },
    paths: {
        ias: 'WeltPixel_AjaxInfiniteScroll/js/jquery-ias.min'
    },
    shim : {
        ias: ['jquery']
    }
};
