var config = {
    map: {
        '*': {
            full_page: 'WeltPixel_FullPageScroll/js/jquery.fullPage.min',
            scrolloverflow: 'WeltPixel_FullPageScroll/js/scrolloverflow.min',
            fullpagescroll: 'WeltPixel_FullPageScroll/js/fullPageScroll'
        }
    }
};