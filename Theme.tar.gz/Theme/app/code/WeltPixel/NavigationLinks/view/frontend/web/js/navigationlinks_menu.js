define([
    'jquery',
    'jquery/ui',
    'mage/menu' ],
function($){
    $.widget('navigationLinks.menu', $.mage.menu, {

        options: {
            responsive: false,
            expanded: false,
            showDelay: 42,
            hideDelay: 300,
            mediaBreakpoint: '(max-width: ' + window.widthThreshold + 'px)'
        }
    });

    return $.navigationLinks.menu;
});