define(['jquery', 'jquery/ui', 'mage/translate', 'domReady'], function ($) {
    "use strict";

    var navigationJs =
        {
            init: function() {
                var navigation = $('.navigation');
                navigationJs.adjustLevelTopFullwidth(navigation);

                navigation.find('.level0.submenu').on('mouseenter', function() {
                    navigationJs.updateBold($(this));
                });
                var scroll = 15;
                if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
                    scroll = 0;
                }

                var ww = $(window).width() + scroll;
                if (ww <= parseInt(window.widthThreshold)) {
                    $('.navigation').show();
                }

                if (ww >= window.screenM && ww <= parseInt(window.widthThreshold)) {
                    $('body').addClass('mobile-nav');
                    $('#switcher-language').show();
                } else {
                    $('body').removeClass('mobile-nav');
                    if ($('.nav-toggle').is(':visible')) {
                        $('#switcher-language').hide();
                    }
                }
            },
            adjustLevelTopFullwidth: function() {
                var pageWrapperW = $('.page-wrapper').width(),
                    headerContentW = $('.header.content').outerWidth(),
                    fullwidthWrapper = $('.navigation').find('.fullwidth-wrapper');

                fullwidthWrapper.each(function() {
                    $(this)
                        .css({'width': pageWrapperW + 'px'})
                        .find('.fullwidth-wrapper-inner')
                        .css({'width': headerContentW + 'px'});
                });
            },
            updateBold: function(el) {
                var parent = el.closest('.megamenu').find('a.level-top');
                parent.addClass('bold-menu');
                el.on('mouseleave', function() {
                    parent.removeClass('bold-menu');
                });
            }
        };

    return navigationJs;
});