var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/view/registration': {
                'WeltPixel_ThankYouPage/js/view/registration': true
            }
        }
    }
};